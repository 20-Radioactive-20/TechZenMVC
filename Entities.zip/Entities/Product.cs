﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Entities
{
    public class Product
    {
        [Display(Name = "Company")]
        public string Company { get; set; }
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Category")]
        public string Category { get; set; }
        [Display(Name = "Quantity")]
        [DataType(DataType.PhoneNumber)]
        public int Quantity { get; set; }
        [Display(Name = "Price")]
        [DataType(DataType.Currency)]
        public long Price { get; set; }
        //public List<Product> products { get; set; }
        public Product(string company, string name, string category, int quantity, long price)
        {
            Company = company;
            Name = name;
            Category = category;
            Quantity = quantity;
            Price = price;
        }
        public Product()
        {

        }
    }
}
