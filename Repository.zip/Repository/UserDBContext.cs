﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Entities;

namespace Repository
{
    public partial class UserDBContext : DbContext
    {
       
        public UserDBContext()
        {
            
        }
        public UserDBContext(DbContextOptions<UserDBContext> options)
            : base(options)
        {
        }
        //setting DBset for each of the entitites
        public DbSet<Product> Product { get; set; }
        public DbSet<User> User { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //speciying the connection string
                optionsBuilder.UseSqlServer("Server=tcp:techzenecommerce.database.windows.net,1433;Initial Catalog=TechZenServer;Persist Security Info=False;User ID=TechZenAdmin;Password=Niit@#123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //mapping between entity and database table
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("tblUser");
                entity.HasNoKey();
                entity.Property(e => e.Name).HasColumnName("Name");
                entity.Property(e => e.Phone)
                    .HasMaxLength(10)
                    .IsUnicode(true)
                    .HasColumnName("Phone");
                entity.Property(e => e.Email)
                    .HasMaxLength(25)
                    .IsUnicode(true)
                    .HasColumnName("Email");
                entity.Property(e => e.Password)
                   .HasMaxLength(15)
                   .IsUnicode(true)
                   .HasColumnName("Password");
            });
            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("tblProducts");
                entity.HasNoKey();
                entity.Property(e => e.Company).HasColumnName("ProductCompany");

                entity.Property(e => e.Name)
                    .HasMaxLength(25)
                    .IsUnicode(true)
                    .HasColumnName("ProductName");

                entity.Property(e => e.Category)
                    .HasMaxLength(20)
                    .IsUnicode(true)
                    .HasColumnName("ProductCategory");
                entity.Property(e => e.Quantity)
                   .HasMaxLength(15)
                   .IsUnicode(true)
                   .HasColumnName("ProductQuantity");
                entity.Property(e => e.Price)
                   .HasMaxLength(15)
                   .IsUnicode(true)
                   .HasColumnName("ProductPrice");
            });

            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
