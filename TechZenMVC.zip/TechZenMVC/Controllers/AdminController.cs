﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Entities;
using Repository;
using System.Data.SqlClient;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Diagnostics;

namespace TechZenMVC.Controllers
{
    public class AdminController : Controller
    {
        private SqlConnection GetConnection()
        {
            string connectionString = "Server=tcp:techzenecommerce.database.windows.net,1433;Initial Catalog=TechZenServer;Persist Security Info=False;User ID=TechZenAdmin;Password=Niit@#123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            return new SqlConnection(connectionString);
        }
        public IActionResult AddProducts()
        {
            return View();
        }
        public IActionResult Add(Product product)
        {
                string statement = String.Format("Insert into tblProducts(ProductCompany,ProductName,ProductCategory,ProductQuantity,ProductPrice) VALUES(@Company,@Name,@Category,@Quantity,@Price)");
                SqlConnection sqlConnection = GetConnection();
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
                sqlCommand.Parameters.AddWithValue("@Company", product.Company);
                sqlCommand.Parameters.AddWithValue("@Name", product.Name);
                sqlCommand.Parameters.AddWithValue("@Category", product.Category);
                sqlCommand.Parameters.AddWithValue("@Quantity", product.Quantity);
                sqlCommand.Parameters.AddWithValue("@Price", product.Price);
                int rowsAffected = sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
                return RedirectToAction("AddProducts");
        }
        public IActionResult ViewUsers()
        {
            List<User> users = new List<User>();          
            try
            {
            using (UserDBContext db = new UserDBContext())
            {
                users = db.User.ToList();
            }
            }
            catch (Exception ex)
            {
               Console.WriteLine(ex.Message);
            }
            Console.WriteLine(users.Count);
            return View(users);
        }
        public IActionResult ViewProducts()
        {
            List<Product> products = new List<Product>();
            try
            {
                using (UserDBContext db = new UserDBContext())
                {
                    products = db.Product.ToList();
                }
            }
            catch (Exception ex)
            {
            }
            Console.WriteLine(products.Count);
            return View(products);
        }
        public IActionResult DeleteUsers()
        {
            List<User> users = new List<User>();
            try
            {
                using (UserDBContext db = new UserDBContext())
                {
                    users = db.User.ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine(users.Count);
            return View(users);
        }
        public IActionResult DeleteUser()
        {

            string statement = String.Format("Delete from tblUser where Email='geetha1@gmail.com'");
            SqlConnection sqlConnection = GetConnection();
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
            int rowsAffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            return RedirectToAction("ViewUsers");
        }
        public IActionResult DeleteProducts()
        {

            List<Product> products = new List<Product>();
            try
            {
                using (UserDBContext db = new UserDBContext())
                {
                    products = db.Product.ToList();
                }
            }
            catch (Exception ex)
            {
            }
            Console.WriteLine(products.Count);
            return View(products);
        }
        public IActionResult DeleteProduct()
        {
            string statement = String.Format("Delete from tblProducts where ProductName='Realme 8'");
            SqlConnection sqlConnection = GetConnection();
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
            int rowsAffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            return RedirectToAction("ViewProducts");
        }
        public IActionResult UpdateProducts()
        {
            List<Product> products = new List<Product>();
            try
            {
                using (UserDBContext db = new UserDBContext())
                {
                    products = db.Product.ToList();
                }
            }
            catch (Exception ex)
            {
            }
            Console.WriteLine(products.Count);
            return View(products);
        }
        public IActionResult UpdateProduct()
        {
            return View("UpdateProduct");
        }
            public IActionResult Update (Product product)
        {
            string statement = String.Format("UPDATE tblProducts SET  ProductCompany=@Company,ProductName=@Name,ProductCategory=@Category,ProductQuantity=@Quantity,ProductPrice= @Price where ProductName='Hp-2001TX'");
            SqlConnection sqlConnection = GetConnection();
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
            sqlCommand.Parameters.AddWithValue("@Company", product.Company);
            sqlCommand.Parameters.AddWithValue("@Name", product.Name);
            sqlCommand.Parameters.AddWithValue("@Category", product.Category);
            sqlCommand.Parameters.AddWithValue("@Quantity", product.Quantity);
            sqlCommand.Parameters.AddWithValue("@Price", product.Price);
            int rowsAffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            return RedirectToAction("ViewProducts");
        }
    }
}

