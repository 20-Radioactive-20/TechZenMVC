﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TechZenMVC.Models;
using Entities;
using System.Data.SqlClient;

namespace TechZenMVC.Controllers
{
    public class HomeController : Controller
    {
        private SqlConnection GetConnection()
        {

            string connectionString = "Server=tcp:techzenecommerce.database.windows.net,1433;Initial Catalog=TechZenServer;Persist Security Info=False;User ID=TechZenAdmin;Password=Niit@#123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            return new SqlConnection(connectionString);
        }
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public IActionResult Index()
        {
            return View();
        }
        
         public IActionResult Careers()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Return()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Advertize()
        {
            return View();
        }
        public IActionResult Download()
        {
            return View();
        }
        public IActionResult Brands()
        {
            return View();
        }
        public IActionResult T_C()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }        
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}