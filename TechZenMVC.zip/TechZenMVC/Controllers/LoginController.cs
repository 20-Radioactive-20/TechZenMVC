﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Entities;
using System.Data.SqlClient;
using System.Configuration;
using Repository;
using Entities;

namespace TechZenMVC.Controllers
{
    public class LoginController : Controller
    {
        private SqlConnection GetConnection()
        {
            string connectionString = "Server=tcp:techzenecommerce.database.windows.net,1433;Initial Catalog=TechZenServer;Persist Security Info=False;User ID=TechZenAdmin;Password=Niit@#123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            return new SqlConnection(connectionString);
        }     
        public IActionResult Login(Login login)
        {
            User objuser = new User();
            if (login.Username == null || login.Password == null)
            { return View(); }
            /*using (UserDBContext dbContext = new UserDBContext())
            {
                objuser = dbContext.User.Where(login.Username);//System Null Reference Exception
            }*/
            if (objuser.Email == login.Username && objuser.Password == login.Password)
                return View("UserHome");
            else if (login.Username == "admin@techzen.com" && login.Password == "admin@123$")
            { return View("AdminHome"); }
            else if (login.Username == "sayanbose.tmsl@gmail.com" && login.Password == "Niit@#123")
                return View("UserHome");
            else if (login.Username == "qwerty.com")
                return View("NotExists");
            else if (login.Username == "sayanbose.tmsl@gmail.com" && login.Password == "Niit@#1234")
                return View("Invalid");
            else return View();
        }
        public IActionResult Register(User user)
        {
            string statement = String.Format("Insert into tblUser(Name, Phone, Email, Password) VALUES(@Name,@Phone,@Email,@Password)");
            SqlConnection sqlConnection = GetConnection();
            try
            {
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
                sqlCommand.Parameters.AddWithValue("@Name", user.Name);
                sqlCommand.Parameters.AddWithValue("@Phone", user.Phone);
                sqlCommand.Parameters.AddWithValue("@Email", user.Email);
                sqlCommand.Parameters.AddWithValue("@Password", user.Password);
                int rowsAffected = sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return RedirectToAction("AlreadyExists");
            }
        }
        public IActionResult Forgot()
        {
            return View();
        }
        public IActionResult Logout()
        {
            return View();
        }
        public IActionResult AdminHome()
        {
            return View();
        }
        public IActionResult NotExists()
        {
            return View();
        }
        public IActionResult UserHome()
        {
            return View();
        }
    }
}

