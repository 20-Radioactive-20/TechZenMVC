﻿using Microsoft.AspNetCore.Mvc;
using Entities;
using Repository;

namespace TechZenMVC.Controllers
{
    public class UserController : Controller
    {
        public IActionResult ViewProducts()
        {
            List<Product> products = new List<Product>();
            try
            {
                using (UserDBContext db = new UserDBContext())
                {
                    products = db.Product.ToList();
                }
            }
            catch (Exception ex)
            {
            }
            Console.WriteLine(products.Count);
            return View(products);
        }
        public IActionResult AddtoCart()
        {
            return View("AddCart");
        }
        public IActionResult PlaceOrder()
        {
            return View("OrderPlaced");
        }
        public IActionResult Buy()
        {
            return View("Buy");
        }
        public IActionResult OrderSummary()
        {
            return View();
        } 
        public IActionResult Enlarged()
        {
            return View("ViewEnlarged");
        }
        public IActionResult UserCart()
        {
            return View();
        }
    }
}
