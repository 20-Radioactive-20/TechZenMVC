﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace TechZenMVC.Models
{
    public class Order
    {
        [Required(ErrorMessage = "Enter Name!")]
        [Display(Name = "Name :")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Enter House number!")]
        [Display(Name = " HouseNumber :")]
        public string HouseNumber { get; set; }

        [Required(ErrorMessage = "Enter AddressLine1!")]
        [Display(Name = "AddressLine1 :")]
        public string AddressLine1 { get; set; }

        [Required(ErrorMessage = "Enter District")]
        [Display(Name = " District :")]
        public string District { get; set; }

        [Required(ErrorMessage = "Enter City!")]
        [Display(Name = " City :")]
        public string City { get; set; }

        [Required(ErrorMessage = "Enter State!")]
        [Display(Name = " State :")]
        public string State { get; set; }

        [Required(ErrorMessage = "Enter Country!")]
        [Display(Name = " Country :")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Enter EmailID!")]
        [Display(Name = " EmailID :")]
        public string EmailID { get; set; }
        [Required(ErrorMessage = "Enter PhoneNumber!")]
        [Display(Name = " PhoneNumber :")]
        public string PhoneNumber { get; set; }



        [Required(ErrorMessage = "Enter UPI ID!")]
        [Display(Name = "UPI ID :")]
        public string UPI_ID { get; set; }


        [Required(ErrorMessage = "Enter Account Number!")]
        [Display(Name = "Account Number :")]
        public string AccountNumber { get; set; }


        [Required(ErrorMessage = "Enter Account Holder Name!")]
        [Display(Name = "Account Holder Name :")]
        public string AccountHolderName { get; set; }


        [Required(ErrorMessage = "Enter Debit/Credit Card Number!")]
        [Display(Name = "Debit/Credit Card Number :")]
        public string CardNumber { get; set; }


        [Required(ErrorMessage = "Enter CVV!")]
        [Display(Name = "CVV :")]
        public string CVV { get; set; }


        [Required(ErrorMessage = "Enter Date Of Expiry!")]
        [Display(Name = "Valid Upto :")]
        public string ValidUpto { get; set; }
    }
}