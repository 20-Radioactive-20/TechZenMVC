﻿using Entities;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ProductService
    {
        private SqlConnection GetConnection()
        {

            string connectionString = "Server=tcp:techzenecommerce.database.windows.net,1433;Initial Catalog=TechZenServer;Persist Security Info=False;User ID=TechZenAdmin;Password=Niit@#123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            return new SqlConnection(connectionString);
        }
        public List<Product> GetProducts()
        {
            List<Product> productList = new List<Product>();
            string statement = "SELECT ProductCompany,ProductName,ProductCategory,ProductQuantity,ProductPrice from tblProducts";
            SqlConnection sqlConnection = GetConnection();

            sqlConnection.Open();

            SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);

            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
                while (sqlDataReader.Read())
                {
                    Product _product = new Product()
                    {
                        Company = sqlDataReader.GetString(0),
                        Name = sqlDataReader.GetString(1),
                        Category = sqlDataReader.GetString(2),
                        Quantity = sqlDataReader.GetInt32(3),
                        Price = sqlDataReader.GetInt64(4)
                    };

                    productList.Add(_product);
                }
            }
            sqlConnection.Close();
            return productList;
        }

        public Product GetProduct(string _productId)
        {
            int productId = int.Parse(_productId);
            string statement = String.Format("SELECT ProductCompany,ProductName,,ProductCategory ProductQuantity ,ProductPrice from tblProduct");
            SqlConnection sqlConnection = GetConnection();

            sqlConnection.Open();

            SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
            Product product = new Product();
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
                sqlDataReader.Read();

                product.Company = sqlDataReader.GetString(0);
                product.Name = sqlDataReader.GetString(1);
                product.Category = sqlDataReader.GetString(2);
                product.Quantity = sqlDataReader.GetInt32(3);
                product.Price = sqlDataReader.GetInt32(4);
                return product;
            }
        }

        public int AddProduct(Product product)
        {
            string statement = String.Format("INSERT INTO tblProducts(,ProductCompany,ProductName,ProductCategory,ProductQuantity) VALUES({0},'{1}',{2},{3})", product.Company, product.Name, product.Category, product.Quantity, product.Price);
            SqlConnection sqlConnection = GetConnection();

            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(statement, sqlConnection);
            int rowsAffected = sqlCommand.ExecuteNonQuery();
            return rowsAffected;
        }
    }

}